import React from 'react';
import HomePage from './pages/HomePage';
import NotFound from './pages/NotFound';
import AddPage from './pages/AddPage';
import Navigation from './components/Navigation';
import DetailPage from './pages/DetailPage'
import {Routes, Route, Link} from 'react-router-dom';
import ArsipPage from './pages/ArsipPage';


function App() {
  return (
    <>
    <div className='app-container'>
      <header>
        <h1>
          <Link to="/">Aplikasi Catatan</Link>
        </h1>
        <Navigation/>
      </header>
      <main>
        <Routes>
          <Route path='/' element={<HomePage/>}/>
          <Route path='/notes/new' element={<AddPage/>}/>
          <Route path='/notes/:id' element={<DetailPage/>}/>
          <Route path='/archives' element={<ArsipPage/>}/>
          <Route path='*' element={<NotFound/>}/>
        </Routes>
      </main>
    </div>
    </>
  );
}

export default App;
